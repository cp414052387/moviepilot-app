# MoviePilot App 项目总结

## 项目位置
`/tmp/moviepilot_app`

## 项目结构

```
moviepilot_app/
├── lib/
│   ├── api/
│   │   └── moviepilot_api.dart      # API 服务层，包含所有 MoviePilot API 调用
│   ├── models/
│   │   └── media.dart               # 数据模型：MediaItem, Subscription, DownloadTask, SystemStatus
│   ├── providers/
│   │   ├── app_provider.dart        # 应用级 provider（空文件）
│   │   └── settings_provider.dart   # 设置状态管理
│   ├── screens/
│   │   ├── home_screen.dart         # 主页面，底部导航
│   │   ├── setup_screen.dart        # 初始化设置页面
│   │   ├── media_library_screen.dart # 媒体库页面
│   │   ├── subscriptions_screen.dart # 订阅管理页面
│   │   ├── downloads_screen.dart    # 下载任务页面
│   │   ├── history_screen.dart      # 历史记录页面
│   │   └── settings_screen.dart     # 设置页面
│   ├── theme/
│   │   └── app_theme.dart           # 主题配置（浅色/深色）
│   ├── widgets/                     # 自定义组件（预留目录）
│   ├── main.dart                    # 应用入口
│   └── lib.dart                     # 导出文件
├── android/                         # Android 配置
│   └── app/
│       └── src/main/
│           ├── AndroidManifest.xml
│           └── res/values/styles.xml
├── assets/                          # 资源文件
│   ├── images/
│   ├── icons/
│   └── animations/
├── pubspec.yaml                     # 项目配置和依赖
├── README.md                        # 项目说明
├── run.sh                           # 启动脚本
├── .gitignore
└── analysis_options.yaml
```

## 主要功能

### 1. 初始化设置 (SetupScreen)
- 输入 MoviePilot API 地址
- 可选输入 API Key（如果需要认证）
- 测试连接功能

### 2. 媒体库 (MediaLibraryScreen)
- 网格展示电影和电视剧
- 显示评分、年份、下载状态
- 下拉刷新
- 搜索功能（预留）
- 点击查看详情

### 3. 订阅管理 (SubscriptionsScreen)
- 浮动按钮添加新订阅
- 支持电影和剧集订阅
- 显示订阅状态（等待中、下载中、已完成、失败）
- 删除订阅功能

### 4. 下载管理 (DownloadsScreen)
- 显示所有下载任务
- 显示下载进度、速度、大小
- 暂停/继续下载
- 删除下载任务
- 下拉刷新

### 5. 历史记录 (HistoryScreen)
- 显示操作历史
- 上拉加载更多
- 显示操作类型（下载、删除、订阅）
- 成功/失败状态标识

### 6. 设置 (SettingsScreen)
- API 地址配置
- API Key 配置
- 主题模式（浅色/深色/跟随系统）
- 自动刷新设置
- 刷新间隔配置（10/30/60/120秒）
- 推送通知开关
- 版本信息和开源许可

## 技术亮点

### 状态管理
- 使用 `flutter_riverpod` 进行状态管理
- `settingsProvider` 管理应用设置
- `apiProvider` 提供 API 实例

### 网络请求
- 使用 `dio` 进行 HTTP 请求
- 统一的错误处理
- 请求/响应拦截器用于日志

### UI 设计
- Material Design 3 设计规范
- 自定义主题颜色（MoviePilot 风格深蓝色）
- 支持浅色/深色模式
- 使用 `shimmer` 实现加载效果
- 使用 `pull_to_refresh` 实现下拉刷新
- 使用 `cached_network_image` 缓存图片

### 数据持久化
- 使用 `shared_preferences` 保存设置
- 使用 `flutter_secure_storage` 存储敏感信息

## 依赖包

```yaml
# 状态管理
- provider
- flutter_riverpod

# 网络请求
- dio
- connectivity_plus

# 存储
- shared_preferences
- flutter_secure_storage

# UI 组件
- flutter_svg
- cached_network_image
- shimmer
- pull_to_refresh
- animations
- lottie

# 工具类
- intl
- url_launcher
- path_provider
- permission_handler

# 图标
- material_design_icons_flutter
```

## 快速开始

### 1. 安装 Flutter SDK
```bash
# macOS
brew install --cask flutter

# 或者从官网下载
# https://flutter.dev/docs/get-started/install
```

### 2. 验证安装
```bash
flutter doctor
```

### 3. 进入项目目录
```bash
cd /tmp/moviepilot_app
```

### 4. 安装依赖
```bash
flutter pub get
```

### 5. 运行应用
```bash
# 使用启动脚本
./run.sh

# 或直接运行
flutter run

# 在 Chrome 中运行（调试）
flutter run -d chrome
```

### 6. 构建应用
```bash
# 构建 APK
flutter build apk --release

# 构建 App Bundle（用于 Google Play）
flutter build appbundle --release
```

## 配置 MoviePilot

1. 启动应用后，会进入设置页面
2. 输入你的 MoviePilot 服务器地址，如：
   - `http://192.168.1.100:3001`
   - `https://moviepilot.example.com`
3. 如果配置了 API Key，也一并输入
4. 点击"测试连接"验证
5. 保存后即可使用

## API 说明

应用通过以下 API 与 MoviePilot 服务端通信：

- `GET /api/system/status` - 获取系统状态
- `GET /api/media/libraries` - 获取媒体库列表
- `GET /api/media/list` - 获取媒体列表
- `GET /api/media/search` - 搜索媒体
- `GET /api/subscribe/list` - 获取订阅列表
- `POST /api/subscribe/add` - 添加订阅
- `DELETE /api/subscribe/{id}` - 删除订阅
- `GET /api/download/list` - 获取下载列表
- `POST /api/download/{id}/pause` - 暂停下载
- `POST /api/download/{id}/start` - 开始下载
- `DELETE /api/download/{id}` - 删除下载
- `GET /api/history/list` - 获取历史记录

详细 API 文档：https://api.movie-pilot.org

## 下一步建议

### 功能增强
1. **搜索功能** - 实现媒体搜索
2. **媒体详情** - 完善媒体详情页面（演员、导演、标签等）
3. **播放控制** - 集成播放器
4. **离线缓存** - 缓存媒体信息
5. **推送通知** - 实现下载完成等通知
6. **多语言** - 支持国际化
7. **多账户** - 支持多个 MoviePilot 服务器

### 代码优化
1. 添加单元测试
2. 添加集成测试
3. 性能优化（列表虚拟化）
4. 错误监控集成
5. 日志系统

### UI 优化
1. 添加更多动画效果
2. 自定义加载动画
3. 适配平板
4. 深色模式图标适配

## 注意事项

1. **Flutter 版本** - 需要 Flutter 3.0+ / Dart 3.0+
2. **Android SDK** - 最低 SDK 21（Android 5.0）
3. **网络权限** - 已在 AndroidManifest.xml 中配置
4. **HTTP 请求** - 如果使用 HTTPS 证书不受信任，需要配置网络安全策略
5. **图片加载** - 使用占位图，避免加载失败影响体验

## 项目完成度

✅ 项目结构完整
✅ 所有页面已创建
✅ API 服务层已完成
✅ 数据模型已定义
✅ 主题配置已完成
✅ 状态管理已实现
✅ Android 配置已完成
✅ 启动脚本已创建
✅ 文档已完善

⚠️ 需要安装 Flutter SDK 才能运行
⚠️ 需要配置 MoviePilot 服务器
⚠️ 需要真机或模拟器才能运行

---

**项目已创建完成！** 🎉
